Create a tag




































































































































































Jump to Content
SDKs
API Definition
Login to Atlas
API Definition
Login to Atlas
Moon (Dark Mode)
Sun (Light Mode)
SDKs
API Definition
Create a tag
Search
All
Pages
Start
 typing to search…
JUMP TO
Introduction
Authentication
Atlas API
Conversations
List all conversations
get
Create conversation
post
Update Conversation
post
Retrieve conversation
get
List conversation messages
get
Send Agent Message
post
Save Customer Message
post
Sidebars
List all the sidebar for a conversation
get
create a sidebar
post
Send a new message in a sidebar
post
Customers
List all customers
get
Create customer
post
Update customer
post
Upsert customer
post
Retrieves one customer
post
Accounts
List all accounts
get
Retrieve one account
get
Upsert account
post
Sessions
List session recordings
get
Get session recording video
get
Request session recording video with callback
post
Configuration
Sla Rules
List all configured sla rules
get
Create sla rule
post
Retrieve one sla rule
get
Update sla rule
post
Tags
List all the tags
get
Create a tag
post
Update a tag
post
List all the tag groups
get
Create a tag group
post
Update a tag group
post
Canned Responses
List all canned responses
get
Create canned response
post
Retrieve one canned response
get
Update canned response
post
Custom Fields
List all custom fields
get
Create custom field
post
Retrieve one custom field
get
Update custom field
post
Users
List all users
get
Create user
post
Retrieve user status
get
Retrieve one user
get
Update user
post
Webhooks
Introduction
Webhooks
List all the the webhook and their subscriptions
get
Create a webhook subscriptions
post
Update a webhook subscriptions
post
List all the the webhook execution logs
get
Custom Events
Introduction
Custom Events
List all the the events
get
Create a new custom event
post
Powered by 
JUMP TO
Introduction
Authentication
Atlas API
Conversations
List all conversations
get
Create conversation
post
Update Conversation
post
Retrieve conversation
get
List conversation messages
get
Send Agent Message
post
Save Customer Message
post
Sidebars
List all the sidebar for a conversation
get
create a sidebar
post
Send a new message in a sidebar
post
Customers
List all customers
get
Create customer
post
Update customer
post
Upsert customer
post
Retrieves one customer
post
Accounts
List all accounts
get
Retrieve one account
get
Upsert account
post
Sessions
List session recordings
get
Get session recording video
get
Request session recording video with callback
post
Configuration
Sla Rules
List all configured sla rules
get
Create sla rule
post
Retrieve one sla rule
get
Update sla rule
post
Tags
List all the tags
get
Create a tag
post
Update a tag
post
List all the tag groups
get
Create a tag group
post
Update a tag group
post
Canned Responses
List all canned responses
get
Create canned response
post
Retrieve one canned response
get
Update canned response
post
Custom Fields
List all custom fields
get
Create custom field
post
Retrieve one custom field
get
Update custom field
post
Users
List all users
get
Create user
post
Retrieve user status
get
Retrieve one user
get
Update user
post
Webhooks
Introduction
Webhooks
List all the the webhook and their subscriptions
get
Create a webhook subscriptions
post
Update a webhook subscriptions
post
List all the the webhook execution logs
get
Custom Events
Introduction
Custom Events
List all the the events
get
Create a new custom event
post
Powered by 
Create a tag
post
 
https://api.atlas.so
/v1/tags
Creates a tag
Language
Shell
Node
Ruby
PHP
Python
Credentials
Bearer
Bearer
RESPONSE
Click 
Try It!
 to start a request and see the response here!